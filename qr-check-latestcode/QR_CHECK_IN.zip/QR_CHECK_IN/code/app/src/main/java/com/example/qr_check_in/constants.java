package com.example.qr_check_in;

import com.example.qr_check_in.ModelClasses.AttendeeCount;

import java.util.ArrayList;

public class constants {
    public static  String SELECTEDEVENTIDREQUIRED = "";

    public static String PREFERENCES = "com.qr.preferences";

    public static String COUNTNUMBEROFTIMELOGIN = "TOKEN";

    public static String DEVICEID = "DEVICEID";








}
