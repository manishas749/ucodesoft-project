package com.example.qr_check_in.StartupFragments;
import com.journeyapps.barcodescanner.CaptureActivity;

public class CaptureAct extends CaptureActivity
{
}