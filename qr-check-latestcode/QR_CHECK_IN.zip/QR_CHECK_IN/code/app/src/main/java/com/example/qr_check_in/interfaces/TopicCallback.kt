package com.mikeschvedov.pushnotificationtutorial.interfaces

interface TopicCallback {
    fun onSubscribed()
}